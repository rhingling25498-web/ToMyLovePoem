package com.daily.tomylove

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*
import android.view.animation.AccelerateDecelerateInterpolator
import android.media.MediaPlayer
import org.json.JSONArray
import android.animation.ObjectAnimator
import android.animation.ValueAnimator

class MainActivity : Activity() {
    private val pink = Color.rgb(216, 91, 136)
    private val pale = Color.rgb(255, 239, 246)
    private val ink = Color.rgb(91, 55, 72)
    private lateinit var content: LinearLayout
    private var musicPlayer: MediaPlayer? = null
    private var musicOn = false
    private var atHome = true
    private val photoRequestCode = 4107
    private val memoryPhotos = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(248, 218, 231)
        window.navigationBarColor = Color.rgb(255, 239, 246)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
            View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        loadMemoryPhotos()
        showHome()
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (!atHome) showHome() else super.onBackPressed()
    }

    private fun toggleMusic() {
        try {
            if (musicPlayer == null) {
                musicPlayer = MediaPlayer.create(this, R.raw.poem_background)?.apply {
                    isLooping = true
                }
            }
            val player = musicPlayer
            if (player == null) {
                Toast.makeText(this, "Music could not be loaded.", Toast.LENGTH_SHORT).show()
                return
            }
            if (musicOn) {
                player.pause()
                musicOn = false
                Toast.makeText(this, "Background music paused", Toast.LENGTH_SHORT).show()
            } else {
                player.start()
                musicOn = true
                Toast.makeText(this, "Playing Poem's song ❤️", Toast.LENGTH_SHORT).show()
            }
            showHome()
        } catch (e: Exception) {
            Toast.makeText(this, "Unable to play this audio file.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        musicPlayer?.release()
        musicPlayer = null
        super.onDestroy()
    }

    private fun bg(color: Int, radius: Float = 24f): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius }

    private fun text(value: String, size: Float, color: Int = ink, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            gravity = Gravity.CENTER
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(12, 10, 12, 10)
        }

    private fun button(label: String, action: () -> Unit): TextView =
        text(label, 17f, pink, true).apply {
            background = bg(Color.WHITE, 28f)
            elevation = 5f
            setPadding(18, 16, 18, 16)
            setOnClickListener { action() }
        }

    private fun base(title: String, subtitle: String? = null) {
        atHome = false
        val scroll = ScrollView(this).apply { setBackgroundColor(pale) }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 24, 22, 32)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        scroll.addView(content)
        setContentView(scroll)
        content.addView(text(title, 29f, pink, true))
        if (subtitle != null) content.addView(text(subtitle, 15f, ink))
    }

    private fun addGap(h: Int = 12) {
        content.addView(View(this), LinearLayout.LayoutParams(1, h))
    }

    private fun showHome() {
        base("To My Love 💗", "For my dearest Poem 🌷\nEvery moment with you is special.")
        addGap(18)
        content.addView(text("🌹  💗  🌹", 34f))
        addGap(12)
        val envelope = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = bg(Color.WHITE, 28f)
            elevation = 6f
            setPadding(22, 24, 22, 24)
            setOnClickListener { showLetter() }
        }
        envelope.addView(text("💌", 58f, pink))
        envelope.addView(text("A little letter for you", 19f, pink, true))
        envelope.addView(text("Tap to open", 14f, ink))
        content.addView(envelope, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ))
        addGap(12)
        content.addView(button("💌  Read Love Letter") { showLetter() })
        addGap()
        content.addView(button("📸  Our Memories") { showMemories() })
        addGap()
        content.addView(button("💕  Our Love Counter") { showCounter() })
        addGap()
        content.addView(button("🎁  Surprise for You") { showSurprise() })
        addGap()
        content.addView(button(if (musicOn) "⏸  Pause Background Music" else "🎵  Play Background Music") {
            toggleMusic()
        })
        addGap(22)
        content.addView(text("Made with love, just for you. ❤️", 14f, pink, true))
    }

    private fun showLetter() {
        base("💌  A Letter for Poem", "A little story that began in 2017…")
        addGap(10)
        content.addView(text("My Love,", 20f, pink, true))
        val letter = """
ချစ်ရတဲ့ Poem ရေ…

ကိုယ်တို့ရဲ့ဇာတ်လမ်းလေးက ၂၀၁၇ ခုနှစ်မှာ စတင်ခဲ့တယ်နော်။

အဲဒီအချိန်တုန်းက ကိုယ်တို့ဟာ ကျောင်းအတူတက်ခဲ့ကြတဲ့ သူငယ်ချင်းတွေပါပဲ။ ဒါပေမဲ့ ကိုယ့်ရင်ထဲမှာတော့ မင်းကို တိတ်တိတ်လေး သဘောကျနေခဲ့မိတယ်။ မင်းမသိခဲ့တဲ့ ကိုယ့်ရဲ့တစ်ဖက်သတ်အချစ်လေးတစ်ခု ရှိနေခဲ့တာပေါ့။

မင်းကို ချစ်နေခဲ့ပေမဲ့ ကိုယ့်ရဲ့ခံစားချက်တွေကို ဖွင့်ပြောဖို့ သတ္တိမရှိခဲ့တဲ့အချိန်တွေလည်း ရှိခဲ့တယ်။

နောက်ဆုံး ၂၀၁၈ ခုနှစ်မှာတော့ ကိုယ်မျှော်လင့်နေခဲ့တဲ့ မင်းဆီက အဖြေလေးကို ရခဲ့တယ်။ အဲဒီနေ့ကစပြီး ကိုယ်တို့နှစ်ယောက်ဟာ ချစ်သူတွေ ဖြစ်လာခဲ့ကြတယ်။

အဲဒီအချိန်လေးကို ပြန်တွေးမိတိုင်း ကိုယ့်အတွက် အရမ်းတန်ဖိုးရှိတဲ့ အမှတ်တရတစ်ခုပါပဲ။

အချစ်ဆိုတာ အမြဲတမ်း ပျော်ရွှင်မှုတွေပဲ မဟုတ်ပေမဲ့ မင်းနဲ့အတူ ဖြတ်သန်းခဲ့တဲ့ အချိန်တိုင်းကို ကိုယ်တန်ဖိုးထားပါတယ်။

နောင်လာမယ့်နေ့ရက်တွေမှာလည်း မင်းရဲ့အပြုံးလေးတွေကို မြင်တွေ့ခွင့်ရချင်တယ်။ မင်းဘေးမှာ အားပေးဖော်၊ နားလည်ပေးဖော်၊ ချစ်ပေးနေမယ့်သူတစ်ယောက်အဖြစ် အမြဲရှိနေချင်တယ်။

၂၀၁၇ မှာ စတင်ခဲ့တဲ့ ကိုယ့်ရဲ့အချစ်လေးဟာ ၂၀၁၈ မှာ အဖြစ်မှန်ဖြစ်လာခဲ့ပြီး ဒီနေ့အထိလည်း မင်းကို ချစ်နေဆဲပါပဲ။
        """.trimIndent()
        val body = text(letter, 17f).apply {
            gravity = Gravity.START
            setLineSpacing(8f, 1.12f)
            background = bg(Color.WHITE, 22f)
            setPadding(20, 22, 20, 22)
        }
        content.addView(body)
        addGap(10)
        content.addView(text("Forever Yours ❤️", 20f, pink, true))
        content.addView(text("Sl", 30f, pink, true))
        addGap(18)
        content.addView(button("← Back to Home") { showHome() })
    }

    private fun loadMemoryPhotos() {
        memoryPhotos.clear()
        val prefs = getSharedPreferences("love_memories", MODE_PRIVATE)
        // V7 stores the gallery in an ordered JSON array. Migrate V5/V6 sets once.
        val ordered = prefs.getString("photos_ordered", null)
        if (ordered != null) {
            try {
                val array = JSONArray(ordered)
                for (i in 0 until array.length()) {
                    val value = array.optString(i)
                    if (value.isNotBlank() && !memoryPhotos.contains(value)) memoryPhotos.add(value)
                }
            } catch (_: Exception) { }
        } else {
            val legacy = prefs.getStringSet("photos", emptySet()) ?: emptySet()
            memoryPhotos.addAll(legacy.sorted())
            saveMemoryPhotos()
        }
    }

    private fun saveMemoryPhotos() {
        val array = JSONArray()
        memoryPhotos.forEach { array.put(it) }
        getSharedPreferences("love_memories", MODE_PRIVATE).edit()
            .putString("photos_ordered", array.toString())
            .putStringSet("photos", memoryPhotos.toSet()) // keep compatibility with older versions
            .apply()
    }

    private fun releasePhotoPermission(uriString: String) {
        try {
            contentResolver.releasePersistableUriPermission(
                Uri.parse(uriString), Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (_: Exception) { }
    }

    private fun chooseMemoryPhotos() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, photoRequestCode)
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != photoRequestCode || resultCode != RESULT_OK || data == null) return
        val selected = mutableListOf<Uri>()
        data.clipData?.let { clip ->
            for (i in 0 until clip.itemCount) selected.add(clip.getItemAt(i).uri)
        } ?: data.data?.let { selected.add(it) }
        selected.forEach { uri ->
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
            if (!memoryPhotos.contains(uri.toString())) memoryPhotos.add(uri.toString())
        }
        saveMemoryPhotos()
        showMemories()
    }

    private fun showMemories() {
        base("📸  Our Memories", "Every little moment is precious.")
        addGap(12)
        content.addView(text("၂၀၁၇  🌸  ကျောင်းအတူတက်ခဲ့တဲ့နေ့ရက်များ", 18f, pink, true))
        content.addView(text("၂၀၁၈  💗  ချစ်သူတွေ ဖြစ်လာခဲ့တဲ့အချိန်", 18f, pink, true))
        addGap(12)
        content.addView(button("＋  Add Photos from Gallery") { chooseMemoryPhotos() })
        addGap(14)
        if (memoryPhotos.isEmpty()) {
            content.addView(text("ကိုယ်တို့ရဲ့ အမှတ်တရဓာတ်ပုံလေးတွေကို ဒီနေရာမှာ ထည့်ထားနိုင်ပါပြီ။", 16f))
        } else {
            content.addView(text("Our Photo Memories 💞 (${memoryPhotos.size})", 18f, pink, true))
            memoryPhotos.forEachIndexed { index, value ->
                try {
                    val image = ImageView(this).apply {
                        setImageURI(Uri.parse(value))
                        scaleType = ImageView.ScaleType.CENTER_CROP
                        background = bg(Color.WHITE, 18f)
                        clipToOutline = true
                        contentDescription = "Memory photo ${index + 1}"
                    setOnClickListener { showPhotoViewer(index) }
                    }
                    content.addView(image, LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, dp(230)
                    ).apply { setMargins(0, 8, 0, 8) })
                    content.addView(text("Tap photo ${index + 1} to view 💗", 12f, pink))
                } catch (_: Exception) {
                    content.addView(text("ဒီဓာတ်ပုံကို ဖွင့်မရတော့ပါ။", 14f))
                }
            }
            addGap(8)
            content.addView(button("🗑  Clear All Memory Photos") {
                memoryPhotos.toList().forEach { releasePhotoPermission(it) }
                memoryPhotos.clear()
                saveMemoryPhotos()
                showMemories()
            })
        }
        addGap(20)
        content.addView(button("← Back to Home") { showHome() })
    }


    private fun showPhotoViewer(startIndex: Int) {
        if (memoryPhotos.isEmpty()) {
            showMemories()
            return
        }
        var current = startIndex.coerceIn(0, memoryPhotos.lastIndex)
        base("💗  Our Memory", "A moment worth keeping forever.")
        val photo = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            background = bg(Color.WHITE, 18f)
            clipToOutline = true
        }
        val counter = text("", 15f, pink, true)
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val previous = button("← Previous") { }
        val next = button("Next →") { }
        fun refreshPhoto() {
            if (memoryPhotos.isEmpty()) {
                showMemories()
                return
            }
            current = current.coerceIn(0, memoryPhotos.lastIndex)
            photo.setImageURI(Uri.parse(memoryPhotos[current]))
            counter.text = "${current + 1} / ${memoryPhotos.size}"
            previous.isEnabled = current > 0
            previous.alpha = if (current > 0) 1f else 0.4f
            next.isEnabled = current < memoryPhotos.lastIndex
            next.alpha = if (current < memoryPhotos.lastIndex) 1f else 0.4f
        }
        previous.setOnClickListener {
            if (current > 0) { current--; refreshPhoto() }
        }
        next.setOnClickListener {
            if (current < memoryPhotos.lastIndex) { current++; refreshPhoto() }
        }
        content.addView(photo, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(390)
        ).apply { setMargins(0, dp(12), 0, dp(8)) })
        content.addView(counter)
        controls.addView(previous, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(4, 4, 4, 4) })
        controls.addView(next, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(4, 4, 4, 4) })
        content.addView(controls)
        addGap(10)
        content.addView(button("🗑  Delete This Photo") {
            if (current in memoryPhotos.indices) {
                val removedPhoto = memoryPhotos.removeAt(current)
                releasePhotoPermission(removedPhoto)
                saveMemoryPhotos()
                if (memoryPhotos.isEmpty()) showMemories()
                else showPhotoViewer(current.coerceAtMost(memoryPhotos.lastIndex))
            }
        })
        addGap(10)
        content.addView(button("← Back to Memories") { showMemories() })
        refreshPhoto()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun showCounter() {
        base("💕  Our Love Story", "A journey that started with a quiet crush.")
        addGap(18)
        content.addView(text("AUGUST 2017  🌷", 25f, pink, true))
        content.addView(text("The beginning — when I quietly fell for you at school.", 17f))
        addGap(10)
        content.addView(text("2018  💞", 28f, pink, true))
        content.addView(text("The year you gave me your answer, and we became a couple.", 17f))
        addGap(18)
        content.addView(text("The exact day is still a sweet mystery.\nWe can add the date whenever you remember it.", 16f))
        addGap(20)
        content.addView(button("← Back to Home") { showHome() })
    }

    private fun showSurprise() {
        base("🎁  A Surprise for You", "Poem, you are my favorite part of the story.")
        addGap(18)
        val heart = text("💗", 68f, pink, true)
        content.addView(heart)
        ObjectAnimator.ofFloat(heart, "scaleX", 1f, 1.22f, 1f).apply {
            duration = 1300
            repeatCount = ValueAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }
        ObjectAnimator.ofFloat(heart, "scaleY", 1f, 1.22f, 1f).apply {
            duration = 1300
            repeatCount = ValueAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }
        addGap(8)
        content.addView(text("💖     💕     💞     💗", 30f))
        addGap(12)
        content.addView(text("No matter how many pages life has,\nI hope we keep writing our story together.", 19f, pink, true))
        addGap(18)
        content.addView(button("Tap for one more hug 🤗") {
            val burst = text("💗  💖  💕  💞  💗", 28f, pink, true)
            content.addView(burst, content.indexOfChild(heart) + 1)
            burst.alpha = 0f
            burst.translationY = dp(24).toFloat()
            burst.animate().alpha(1f).translationY(0f).setDuration(500).start()
            Toast.makeText(this, "Sending you a thousand hugs, Poem! ❤️", Toast.LENGTH_LONG).show()
        })
        addGap(20)
        content.addView(button("← Back to Home") { showHome() })
    }
}
