# To My Love – Poem 💗 (Version 7)

Native Android Kotlin project for the romantic **To My Love** app.

## Features
- Pink romantic home screen and custom heart launcher icon
- Tap-to-open Love Letter with the 2017 one-sided-love / 2018 relationship story
- Memories page with multi-photo gallery selection
- Photo viewer with Previous / Next and individual photo deletion
- Clear-all photos action
- Love Story timeline (uses August 2017 and 2018; no invented exact date)
- Surprise page with beating heart animation and hug button
- Offline bundled MP3 with looping Play/Pause control

## Version 7 improvements
- App version updated to `1.0.7` (versionCode 7)
- Gallery URI list is stored as an ordered JSON array, so photo order is preserved in future saves
- Existing V5/V6 `photos` preference is migrated on first launch
- Persisted read permission is released when a photo is deleted or all photos are cleared
- Legacy `photos` preference remains written for backwards compatibility

## Music
The supplied MP3 is bundled at `app/src/main/res/raw/poem_background.mp3`.

## Build APK
Requires Android Studio, JDK 17, Android Gradle Plugin 8.6.1, and Android SDK 35.
Open this folder in Android Studio, allow Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
Debug APK output: `app/build/outputs/apk/debug/app-debug.apk`.

The current build environment does not have Gradle or Android SDK installed, so an APK has not been built or tested here.
