plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.daily.tomylove"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.daily.tomylove"
        minSdk = 23
        targetSdk = 35
        versionCode = 7
        versionName = "1.0.7"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
