package com.daily.tomylove

import android.app.Activity
import android.app.DatePickerDialog
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*
import android.view.animation.AccelerateDecelerateInterpolator
import android.media.MediaPlayer
import org.json.JSONArray
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.animation.AnimatorSet
import java.util.Calendar

class MainActivity : Activity() {
    private val pink = Color.rgb(216, 91, 136)
    private val pale = Color.rgb(255, 239, 246)
    private val ink = Color.rgb(91, 55, 72)
    private lateinit var content: LinearLayout
    private var musicPlayer: MediaPlayer? = null
    private var musicOn = false
    private var volumeLevel = 70
    private var atHome = true
    private val photoRequestCode = 4107
    private val memoryPhotos = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(248, 218, 231)
        window.navigationBarColor = Color.rgb(255, 239, 246)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
            View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        volumeLevel = getSharedPreferences("love_settings", MODE_PRIVATE).getInt("music_volume", 70)
        loadMemoryPhotos()
        startBackgroundMusic()
        showHome()
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (!atHome) showHome() else super.onBackPressed()
    }

    private fun startBackgroundMusic() {
        try {
            if (musicPlayer == null) {
                musicPlayer = MediaPlayer.create(this, R.raw.poem_background)?.apply {
                    isLooping = true
                    setVolume(volumeLevel / 100f, volumeLevel / 100f)
                }
            }
            musicPlayer?.let { if (!it.isPlaying) it.start(); musicOn = true }
        } catch (_: Exception) {
            musicOn = false
        }
    }

    private fun updateMusicVolume(value: Int) {
        volumeLevel = value.coerceIn(0, 100)
        musicPlayer?.setVolume(volumeLevel / 100f, volumeLevel / 100f)
        getSharedPreferences("love_settings", MODE_PRIVATE).edit()
            .putInt("music_volume", volumeLevel).apply()
    }

    override fun onDestroy() {
        musicPlayer?.release()
        musicPlayer = null
        super.onDestroy()
    }

    private fun bg(color: Int, radius: Float = 24f): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius }

    private fun text(value: String, size: Float, color: Int = ink, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            gravity = Gravity.CENTER
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(12, 10, 12, 10)
        }

    private fun button(label: String, action: () -> Unit): TextView =
        text(label, 17f, pink, true).apply {
            background = bg(Color.WHITE, 28f)
            elevation = 5f
            setPadding(18, 16, 18, 16)
            setOnClickListener { action() }
        }

    private fun base(title: String, subtitle: String? = null) {
        atHome = false
        val scroll = ScrollView(this).apply { setBackgroundColor(pale) }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 24, 22, 32)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        scroll.addView(content)
        setContentView(scroll)
        content.addView(text(title, 29f, pink, true))
        if (subtitle != null) content.addView(text(subtitle, 15f, ink))
    }

    private fun addGap(h: Int = 12) {
        content.addView(View(this), LinearLayout.LayoutParams(1, h))
    }

    private fun showHome() {
        base("To My Love 💗", "For my dearest Poem 🌷\nEvery moment with you is special.")
        addGap(18)
        content.addView(text("🌹  💗  🌹", 34f))
        addGap(12)
        val envelope = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = bg(Color.WHITE, 28f)
            elevation = 6f
            setPadding(22, 24, 22, 24)
            setOnClickListener { showLetter() }
        }
        envelope.addView(text("💌", 58f, pink))
        envelope.addView(text("A little letter for you", 19f, pink, true))
        envelope.addView(text("Tap to open", 14f, ink))
        content.addView(envelope, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ))
        addGap(12)
        content.addView(button("💌  Read Love Letter") { showLetter() })
        addGap()
        content.addView(button("📸  Our Memories") { showMemories() })
        addGap()
        content.addView(button("💕  Our Love Counter") { showCounter() })
        addGap()
        content.addView(button("🎁  Surprise for You") { showSurprise() })
        addGap()
        val musicCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = bg(Color.WHITE, 22f)
            elevation = 4f
            setPadding(18, 12, 18, 12)
        }
        musicCard.addView(text("🎵  Background Music", 16f, pink, true))
        val volumeLabel = text("အသံအတိုးအလျော့  $volumeLevel%", 13f, ink)
        musicCard.addView(volumeLabel)
        val volumeSlider = SeekBar(this).apply {
            max = 100
            progress = volumeLevel
            progressTintList = android.content.res.ColorStateList.valueOf(pink)
            thumbTintList = android.content.res.ColorStateList.valueOf(pink)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) {
                        updateMusicVolume(progress)
                        volumeLabel.text = "အသံအတိုးအလျော့  $progress%"
                    }
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        musicCard.addView(volumeSlider, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ))
        content.addView(musicCard, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ))
        addGap(22)
        content.addView(text("Made with love, just for you. ❤️", 14f, pink, true))
    }

    private fun showLetter() {
        base("💌  A Letter for Poem", "A little story that began in 2017…")
        addGap(10)
        content.addView(text("My Love,", 20f, pink, true))
        val letter = """
ချစ်ရတဲ့ Poem ရေ…

ကိုယ်တို့ရဲ့ဇာတ်လမ်းလေးက ၂၀၁၇ ခုနှစ်မှာ စတင်ခဲ့တယ်နော်။

အဲဒီအချိန်တုန်းက ကိုယ်တို့ဟာ ကျောင်းအတူတက်ခဲ့ကြတဲ့ သူငယ်ချင်းတွေပါပဲ။ ဒါပေမဲ့ ကိုယ့်ရင်ထဲမှာတော့ မင်းကို တိတ်တိတ်လေး သဘောကျနေခဲ့မိတယ်။ မင်းမသိခဲ့တဲ့ ကိုယ့်ရဲ့တစ်ဖက်သတ်အချစ်လေးတစ်ခု ရှိနေခဲ့တာပေါ့။

မင်းကို ချစ်နေခဲ့ပေမဲ့ ကိုယ့်ရဲ့ခံစားချက်တွေကို ဖွင့်ပြောဖို့ သတ္တိမရှိခဲ့တဲ့အချိန်တွေလည်း ရှိခဲ့တယ်။

နောက်ဆုံး ၂၀၁၈ ခုနှစ်မှာတော့ ကိုယ်မျှော်လင့်နေခဲ့တဲ့ မင်းဆီက အဖြေလေးကို ရခဲ့တယ်။ အဲဒီနေ့ကစပြီး ကိုယ်တို့နှစ်ယောက်ဟာ ချစ်သူတွေ ဖြစ်လာခဲ့ကြတယ်။

အဲဒီအချိန်လေးကို ပြန်တွေးမိတိုင်း ကိုယ့်အတွက် အရမ်းတန်ဖိုးရှိတဲ့ အမှတ်တရတစ်ခုပါပဲ။

အချစ်ဆိုတာ အမြဲတမ်း ပျော်ရွှင်မှုတွေပဲ မဟုတ်ပေမဲ့ မင်းနဲ့အတူ ဖြတ်သန်းခဲ့တဲ့ အချိန်တိုင်းကို ကိုယ်တန်ဖိုးထားပါတယ်။

နောင်လာမယ့်နေ့ရက်တွေမှာလည်း မင်းရဲ့အပြုံးလေးတွေကို မြင်တွေ့ခွင့်ရချင်တယ်။ မင်းဘေးမှာ အားပေးဖော်၊ နားလည်ပေးဖော်၊ ချစ်ပေးနေမယ့်သူတစ်ယောက်အဖြစ် အမြဲရှိနေချင်တယ်။

၂၀၁၇ မှာ စတင်ခဲ့တဲ့ ကိုယ့်ရဲ့အချစ်လေးဟာ ၂၀၁၈ မှာ အဖြစ်မှန်ဖြစ်လာခဲ့ပြီး ဒီနေ့အထိလည်း မင်းကို ချစ်နေဆဲပါပဲ။
        """.trimIndent()
        val body = text(letter, 17f).apply {
            gravity = Gravity.START
            setLineSpacing(8f, 1.12f)
            background = bg(Color.WHITE, 22f)
            setPadding(20, 22, 20, 22)
        }
        content.addView(body)
        addGap(10)
        content.addView(text("Forever Yours ❤️", 20f, pink, true))
        content.addView(text("Sl", 30f, pink, true))
        addGap(18)
        content.addView(button("← Back to Home") { showHome() })
    }

    private fun loadMemoryPhotos() {
        memoryPhotos.clear()
        val prefs = getSharedPreferences("love_memories", MODE_PRIVATE)
        // V7 stores the gallery in an ordered JSON array. Migrate V5/V6 sets once.
        val ordered = prefs.getString("photos_ordered", null)
        if (ordered != null) {
            try {
                val array = JSONArray(ordered)
                for (i in 0 until array.length()) {
                    val value = array.optString(i)
                    if (value.isNotBlank() && !memoryPhotos.contains(value)) memoryPhotos.add(value)
                }
            } catch (_: Exception) { }
        } else {
            val legacy = prefs.getStringSet("photos", emptySet()) ?: emptySet()
            memoryPhotos.addAll(legacy.sorted())
            saveMemoryPhotos()
        }
    }

    private fun saveMemoryPhotos() {
        val array = JSONArray()
        memoryPhotos.forEach { array.put(it) }
        getSharedPreferences("love_memories", MODE_PRIVATE).edit()
            .putString("photos_ordered", array.toString())
            .putStringSet("photos", memoryPhotos.toSet()) // keep compatibility with older versions
            .apply()
    }

    private fun releasePhotoPermission(uriString: String) {
        try {
            contentResolver.releasePersistableUriPermission(
                Uri.parse(uriString), Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (_: Exception) { }
    }

    private fun chooseMemoryPhotos() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, photoRequestCode)
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != photoRequestCode || resultCode != RESULT_OK || data == null) return
        val selected = mutableListOf<Uri>()
        data.clipData?.let { clip ->
            for (i in 0 until clip.itemCount) selected.add(clip.getItemAt(i).uri)
        } ?: data.data?.let { selected.add(it) }
        selected.forEach { uri ->
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
            if (!memoryPhotos.contains(uri.toString())) memoryPhotos.add(uri.toString())
        }
        saveMemoryPhotos()
        showMemories()
    }

    private fun showMemories() {
        base("📸  Our Memories", "Every little moment is precious.")
        addGap(12)
        content.addView(text("၂၀၁၇  🌸  ကျောင်းအတူတက်ခဲ့တဲ့နေ့ရက်များ", 18f, pink, true))
        content.addView(text("၂၀၁၈  💗  ချစ်သူတွေ ဖြစ်လာခဲ့တဲ့အချိန်", 18f, pink, true))
        addGap(12)
        content.addView(button("＋  Add Photos from Gallery") { chooseMemoryPhotos() })
        addGap(14)
        if (memoryPhotos.isEmpty()) {
            content.addView(text("ကိုယ်တို့ရဲ့ အမှတ်တရဓာတ်ပုံလေးတွေကို ဒီနေရာမှာ ထည့်ထားနိုင်ပါပြီ။", 16f))
        } else {
            content.addView(text("Our Photo Memories 💞 (${memoryPhotos.size})", 18f, pink, true))
            memoryPhotos.forEachIndexed { index, value ->
                try {
                    val image = ImageView(this).apply {
                        setImageURI(Uri.parse(value))
                        scaleType = ImageView.ScaleType.CENTER_CROP
                        background = bg(Color.WHITE, 18f)
                        clipToOutline = true
                        contentDescription = "Memory photo ${index + 1}"
                    setOnClickListener { showPhotoViewer(index) }
                    }
                    content.addView(image, LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, dp(230)
                    ).apply { setMargins(0, 8, 0, 8) })
                    content.addView(text("Tap photo ${index + 1} to view 💗", 12f, pink))
                } catch (_: Exception) {
                    content.addView(text("ဒီဓာတ်ပုံကို ဖွင့်မရတော့ပါ။", 14f))
                }
            }
            addGap(8)
            content.addView(button("🗑  Clear All Memory Photos") {
                memoryPhotos.toList().forEach { releasePhotoPermission(it) }
                memoryPhotos.clear()
                saveMemoryPhotos()
                showMemories()
            })
        }
        addGap(20)
        content.addView(button("← Back to Home") { showHome() })
    }


    private fun showPhotoViewer(startIndex: Int) {
        if (memoryPhotos.isEmpty()) {
            showMemories()
            return
        }
        var current = startIndex.coerceIn(0, memoryPhotos.lastIndex)
        base("💗  Our Memory", "A moment worth keeping forever.")
        val photo = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            background = bg(Color.WHITE, 18f)
            clipToOutline = true
        }
        val counter = text("", 15f, pink, true)
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val previous = button("← Previous") { }
        val next = button("Next →") { }
        fun refreshPhoto() {
            if (memoryPhotos.isEmpty()) {
                showMemories()
                return
            }
            current = current.coerceIn(0, memoryPhotos.lastIndex)
            photo.setImageURI(Uri.parse(memoryPhotos[current]))
            counter.text = "${current + 1} / ${memoryPhotos.size}"
            previous.isEnabled = current > 0
            previous.alpha = if (current > 0) 1f else 0.4f
            next.isEnabled = current < memoryPhotos.lastIndex
            next.alpha = if (current < memoryPhotos.lastIndex) 1f else 0.4f
        }
        previous.setOnClickListener {
            if (current > 0) { current--; refreshPhoto() }
        }
        next.setOnClickListener {
            if (current < memoryPhotos.lastIndex) { current++; refreshPhoto() }
        }
        content.addView(photo, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(390)
        ).apply { setMargins(0, dp(12), 0, dp(8)) })
        content.addView(counter)
        controls.addView(previous, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(4, 4, 4, 4) })
        controls.addView(next, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(4, 4, 4, 4) })
        content.addView(controls)
        addGap(10)
        content.addView(button("🗑  Delete This Photo") {
            if (current in memoryPhotos.indices) {
                val removedPhoto = memoryPhotos.removeAt(current)
                releasePhotoPermission(removedPhoto)
                saveMemoryPhotos()
                if (memoryPhotos.isEmpty()) showMemories()
                else showPhotoViewer(current.coerceAtMost(memoryPhotos.lastIndex))
            }
        })
        addGap(10)
        content.addView(button("← Back to Memories") { showMemories() })
        refreshPhoto()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun showCounter() {
        base("💕  Our Love Story", "ကိုယ်တို့နှစ်ယောက်ရဲ့ အချစ်ခရီးလမ်းလေး")
        addGap(14)
        val prefs = getSharedPreferences("love_counter", MODE_PRIVATE)
        val dateText = text("", 15f, ink, true)
        val heartView = text("💗💕", 58f, pink, true)
        val yearsView = text("", 19f, pink, true)
        val daysView = text("", 16f, ink, true)
        val heartPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = bg(Color.WHITE, 28f)
            elevation = 5f
            setPadding(18, 18, 18, 20)
        }
        heartPanel.addView(heartView)
        heartPanel.addView(yearsView)
        heartPanel.addView(daysView)
        val pulseX = ObjectAnimator.ofFloat(heartView, "scaleX", 1f, 1.10f, 1f).apply {
            duration = 1500; repeatCount = ValueAnimator.INFINITE; interpolator = AccelerateDecelerateInterpolator()
        }
        val pulseY = ObjectAnimator.ofFloat(heartView, "scaleY", 1f, 1.10f, 1f).apply {
            duration = 1500; repeatCount = ValueAnimator.INFINITE; interpolator = AccelerateDecelerateInterpolator()
        }
        pulseX.start(); pulseY.start()

        fun refreshCounter() {
            val saved = prefs.getString("start_date", null)
            if (saved.isNullOrBlank()) {
                dateText.text = "စတင်ချစ်ခဲ့တဲ့ရက်ကို ရွေးချယ်ပါ 💗"
                yearsView.text = "ကိုယ်တို့ရဲ့ အချစ်ခရီးလမ်း"
                daysView.text = "ရက်စွဲထည့်ပြီးတာနဲ့ အလိုအလျောက်တွက်ပေးမယ်"
                return
            }
            val parts = saved.split("-")
            if (parts.size != 3) return
            val start = Calendar.getInstance().apply {
                set(parts[0].toInt(), parts[1].toInt() - 1, parts[2].toInt(), 0, 0, 0)
                set(Calendar.MILLISECOND, 0)
            }
            val today = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            if (start.after(today)) {
                dateText.text = "စတင်ရက်က ဒီနေ့ထက် နောက်မကျစေရပါဘူး။"
                yearsView.text = "ရက်စွဲကို ပြန်ရွေးပေးပါနော်"
                daysView.text = ""
                return
            }
            var y = today.get(Calendar.YEAR) - start.get(Calendar.YEAR)
            var m = today.get(Calendar.MONTH) - start.get(Calendar.MONTH)
            var d = today.get(Calendar.DAY_OF_MONTH) - start.get(Calendar.DAY_OF_MONTH)
            if (d < 0) {
                m--
                val previousMonth = (today.clone() as Calendar).apply { add(Calendar.MONTH, -1) }
                d += previousMonth.getActualMaximum(Calendar.DAY_OF_MONTH)
            }
            if (m < 0) { y--; m += 12 }
            dateText.text = "စတင်ခဲ့တဲ့နေ့  $saved"
            yearsView.text = "$y နှစ်   $m လ"
            daysView.text = "$d ရက်  အတူတူချစ်လာခဲ့ပြီ ❤️"
        }

        refreshCounter()
        content.addView(dateText)
        addGap(8)
        content.addView(heartPanel, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ))
        addGap(14)
        content.addView(button("📅  စချစ်ခဲ့တဲ့ရက် ရွေးမယ်") {
            val now = Calendar.getInstance()
            val dialog = DatePickerDialog(this, { _, year, month, day ->
                val chosen = Calendar.getInstance().apply { set(year, month, day) }
                val today = Calendar.getInstance()
                val normalizedToday = (today.clone() as Calendar).apply {
                    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                }
                if (chosen.after(normalizedToday)) {
                    Toast.makeText(this, "ဒီနေ့ထက် နောက်ကျတဲ့ရက်ကို မရွေးပါနဲ့နော်။", Toast.LENGTH_SHORT).show()
                } else {
                    val value = String.format(java.util.Locale.US, "%04d-%02d-%02d", year, month + 1, day)
                    prefs.edit().putString("start_date", value).apply()
                    refreshCounter()
                }
            }, now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH))
            dialog.datePicker.maxDate = System.currentTimeMillis()
            dialog.show()
        })
        addGap(18)
        content.addView(text("၂၀၁၇ ခုနှစ်မှာ စတင်ခဲ့တဲ့ ခံစားချက်လေးဟာ ၂၀၁၈ ခုနှစ်မှာ ချစ်သူတွေဖြစ်လာခဲ့တယ်။ အခုလည်း မင်းကို တန်ဖိုးထားချစ်နေဆဲပါ။", 15f, ink))
        addGap(20)
        content.addView(button("← Back to Home") { showHome() })
    }

    private var lastSurpriseMessage = ""

    private fun makeSurpriseMessage(): String {
        val openings = listOf(
            "Poem ရေ၊ မင်းရှိနေတာလေးက", "မင်းရဲ့အပြုံးလေးက", "မင်းနဲ့အတူရှိတဲ့အချိန်တိုင်းက",
            "မင်းရဲ့အသံလေးကြားရတဲ့အခါတိုင်း", "မင်းကို သတိရမိတဲ့အချိန်တိုင်း",
            "မင်းရဲ့ဂရုစိုက်မှုလေးတွေက", "မင်းနဲ့စကားပြောရတဲ့အချိန်လေးတွေက",
            "မင်းဘေးမှာရှိနေရတာက", "မင်းရဲ့ချစ်ခြင်းမေတ္တာလေးက", "မင်းကို ချစ်ခွင့်ရတာက"
        )
        val middles = listOf(
            "ကိုယ့်ရဲ့နေ့ရက်တွေကို ပိုလှပစေတယ်", "ကိုယ့်နှလုံးသားကို နွေးထွေးစေတယ်",
            "ပင်ပန်းမှုတွေကို မေ့ပျောက်စေတယ်", "ကိုယ့်ဘဝကို အဓိပ္ပာယ်ရှိစေတယ်",
            "ကိုယ့်အတွက် အဖိုးတန်ဆုံးလက်ဆောင်ပါပဲ", "ကိုယ့်ကို အမြဲပြုံးစေတယ်",
            "ဘယ်အရာနဲ့မှ လဲလှယ်လို့မရတဲ့ ပျော်ရွှင်မှုပါပဲ", "ကိုယ့်ရင်ထဲမှာ အမှတ်တရလှလှလေးတွေ ဖြစ်စေတယ်",
            "ကိုယ့်ရဲ့အချစ်ကို ပိုပြီးခိုင်မာစေတယ်", "နေ့တိုင်းကို မျှော်လင့်ချက်တွေနဲ့ ပြည့်စေတယ်"
        )
        val endings = listOf(
            "မင်းကို အမြဲတန်ဖိုးထားနေမယ်နော်။ ❤️", "ဒီအချစ်လေးကို အမြဲစောင့်ရှောက်သွားမယ်။ 💗",
            "မင်းဘေးမှာ အမြဲရှိနေပေးချင်တယ်။ 🥰", "အတူတူ အမှတ်တရအသစ်တွေ ဖန်တီးကြမယ်နော်။ 🌷",
            "မင်းဟာ ကိုယ့်အတွက် ထူးခြားတဲ့သူတစ်ယောက်ပါ။ 💞", "ဒီနေ့ထက် မနက်ဖြန်မှာ ပိုချစ်သွားမယ်။ 💖",
            "ကိုယ့်ရဲ့ရွေးချယ်မှုက မင်းပဲ ဖြစ်နေဦးမှာပါ။ 💘", "Forever Yours ပါ Poem ရေ။ ❤️",
            "အချိန်တွေဘယ်လောက်ပြောင်းပြောင်း မင်းကိုချစ်နေမယ်။ 🌹", "အမြဲတမ်း ပျော်ရွှင်နေပါစေနော်။ 🤗"
        )
        var message: String
        do {
            message = "${openings.random()} ${middles.random()}။ ${endings.random()}"
        } while (message == lastSurpriseMessage)
        lastSurpriseMessage = message
        return message
    }

    private fun showSurprise() {
        base("🎁  A Surprise for You", "Poem, you are my favorite part of the story.")
        addGap(18)
        val heart = text("💗", 68f, pink, true)
        content.addView(heart)
        ObjectAnimator.ofFloat(heart, "scaleX", 1f, 1.22f, 1f).apply {
            duration = 1300
            repeatCount = ValueAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }
        ObjectAnimator.ofFloat(heart, "scaleY", 1f, 1.22f, 1f).apply {
            duration = 1300
            repeatCount = ValueAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }
        addGap(8)
        content.addView(text("💖     💕     💞     💗", 30f))
        addGap(12)
        val messageCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = bg(Color.WHITE, 22f)
            elevation = 4f
            setPadding(20, 22, 20, 18)
        }
        val message = text(makeSurpriseMessage(), 19f, pink, true).apply {
            setLineSpacing(7f, 1.08f)
            alpha = 0f
        }
        val signature = text("𝑺𝑳", 15f, pink, true).apply {
            gravity = Gravity.END
            setPadding(8, 12, 4, 0)
            alpha = 0f
        }
        messageCard.addView(message, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ))
        messageCard.addView(signature, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ))
        content.addView(messageCard, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ))
        fun revealMessage() {
            message.animate().cancel(); signature.animate().cancel()
            message.animate().alpha(0f).translationY(-dp(8).toFloat()).setDuration(220)
                .withEndAction {
                    message.text = makeSurpriseMessage()
                    message.translationY = dp(12).toFloat()
                    signature.translationY = dp(8).toFloat()
                    message.animate().alpha(1f).translationY(0f).setDuration(750)
                        .setInterpolator(AccelerateDecelerateInterpolator()).start()
                    signature.animate().alpha(1f).translationY(0f).setStartDelay(250)
                        .setDuration(650).setInterpolator(AccelerateDecelerateInterpolator()).start()
                }.start()
            heart.animate().scaleX(1.28f).scaleY(1.28f).setDuration(260)
                .withEndAction { heart.animate().scaleX(1f).scaleY(1f).setDuration(420).start() }.start()
        }
        message.post {
            message.translationY = dp(12).toFloat()
            signature.translationY = dp(8).toFloat()
            message.animate().alpha(1f).translationY(0f).setDuration(850)
                .setInterpolator(AccelerateDecelerateInterpolator()).start()
            signature.animate().alpha(1f).translationY(0f).setStartDelay(280)
                .setDuration(700).setInterpolator(AccelerateDecelerateInterpolator()).start()
        }
        addGap(18)
        content.addView(button("နောက်ထပ် အချစ်စာတိုလေး ဖတ်မယ် 💌") { revealMessage() })
        addGap(20)
        content.addView(button("← Back to Home") { showHome() })
    }

}
